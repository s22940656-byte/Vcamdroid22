package com.vcamdroid.ui.components

import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.decode.VideoFrameDecoder
import com.vcamdroid.ui.theme.*
import com.vcamdroid.util.VideoInfo

@Composable
fun VideoPreviewCard(
    videoInfo: VideoInfo?,
    isServiceActive: Boolean,
    onPickVideo: () -> Unit,
    onClearVideo: () -> Unit,
    modifier: Modifier = Modifier
) {
    VcamCard(modifier = modifier) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            // Header row
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Rounded.VideoFile,
                    contentDescription = null,
                    tint = NeonCyan,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "VIDEO SOURCE",
                    style = MaterialTheme.typography.labelSmall,
                    color = NeonCyan
                )
            }

            AnimatedContent(
                targetState = videoInfo,
                transitionSpec = {
                    fadeIn(tween(300)) togetherWith fadeOut(tween(200))
                },
                label = "videoContent"
            ) { info ->
                if (info == null) {
                    // Empty state
                    EmptyVideoState(onPickVideo = onPickVideo)
                } else {
                    // Loaded state
                    LoadedVideoState(
                        videoInfo = info,
                        isServiceActive = isServiceActive,
                        onPickVideo = onPickVideo,
                        onClearVideo = onClearVideo
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyVideoState(onPickVideo: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Dashed drop zone
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(CardNavy)
                .border(
                    width = 1.5.dp,
                    color = BorderBlue,
                    shape = RoundedCornerShape(10.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.CloudUpload,
                    contentDescription = null,
                    tint = TextTertiary,
                    modifier = Modifier.size(40.dp)
                )
                Text(
                    text = "No video selected",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextTertiary
                )
                Text(
                    text = "MP4, MKV, AVI supported",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextTertiary.copy(alpha = 0.6f)
                )
            }
        }

        Button(
            onClick = onPickVideo,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = NeonCyan,
                contentColor = DeepNavy
            ),
            shape = RoundedCornerShape(10.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.FolderOpen,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = "Browse Files",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
            )
        }
    }
}

@Composable
private fun LoadedVideoState(
    videoInfo: VideoInfo,
    isServiceActive: Boolean,
    onPickVideo: () -> Unit,
    onClearVideo: () -> Unit
) {
    val context = LocalContext.current

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Thumbnail + metadata row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            // Video thumbnail
            Box(
                modifier = Modifier
                    .width(110.dp)
                    .height(70.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(CardNavy)
                    .border(1.dp, BorderBlue, RoundedCornerShape(8.dp))
            ) {
                AsyncImage(
                    model = ImageRequest.Builder(context)
                        .data(videoInfo.uri)
                        .decoderFactory(VideoFrameDecoder.Factory())
                        .crossfade(true)
                        .build(),
                    contentDescription = "Video thumbnail",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Duration badge
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(4.dp)
                        .background(
                            Color.Black.copy(alpha = 0.7f),
                            RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = videoInfo.durationFormatted,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White
                    )
                }

                // Active indicator overlay
                if (isServiceActive) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(ActiveGreen.copy(alpha = 0.15f))
                    )
                }
            }

            // Metadata
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = videoInfo.displayName,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimary,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                MetaRow(
                    icon = Icons.Rounded.Timer,
                    value = videoInfo.durationFormatted
                )
                MetaRow(
                    icon = Icons.Rounded.Storage,
                    value = videoInfo.fileSizeFormatted
                )
                MetaRow(
                    icon = Icons.Rounded.VideoSettings,
                    value = videoInfo.mimeType
                )
            }
        }

        // Action buttons
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(
                onClick = onPickVideo,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonCyan),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderBlue),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Rounded.SwapHoriz, null, Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Change", style = MaterialTheme.typography.labelMedium)
            }

            OutlinedButton(
                onClick = onClearVideo,
                enabled = !isServiceActive,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRed),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (!isServiceActive) ErrorRed.copy(0.4f) else BorderBlue
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Rounded.DeleteOutline, null, Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Clear", style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

@Composable
private fun MetaRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    value: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Icon(icon, null, Modifier.size(12.dp), tint = TextSecondary)
        Text(value, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
    }
}
