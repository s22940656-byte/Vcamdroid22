package com.vcamdroid.camera

import android.content.Context
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.hardware.camera2.params.StreamConfigurationMap
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.util.Size
import android.view.Surface

/**
 * VirtualCameraHook
 *
 * This is the camera injection layer. It defines the [CameraInjector] interface
 * and provides concrete implementations for different strategies.
 *
 * ┌─────────────────────────────────────────────────────────────────────────────┐
 * │                    Camera Injection Architecture                             │
 * │                                                                              │
 * │  ┌──────────────┐   frames   ┌──────────────┐   inject   ┌──────────────┐  │
 * │  │  MediaPlayer │──────────► │ FrameBuffer  │──────────► │  Injector   │  │
 * │  └──────────────┘            └──────────────┘            └──────────────┘  │
 * │                                                                  │           │
 * │                              ┌───────────────────────────────────┘           │
 * │                              ▼                                               │
 * │  ┌───────────────┐  ┌────────────────┐  ┌────────────────┐  ┌───────────┐  │
 * │  │ InAppPreview  │  │ VirtualDisplay │  │ Camera2Compat  │  │  Xposed   │  │
 * │  │  (default)    │  │ (MediaProject) │  │  (root/system) │  │ (LSPosed) │  │
 * │  └───────────────┘  └────────────────┘  └────────────────┘  └───────────┘  │
 * └─────────────────────────────────────────────────────────────────────────────┘
 */

// ── Core Interface ────────────────────────────────────────────────────────────

interface CameraInjector {
    /** Capability declaration so the UI can show warnings */
    val requiresRoot: Boolean
    val requiresLSPosed: Boolean
    val displayName: String

    /**
     * Connect the injector to a live [SurfaceTexture] that receives
     * decoded video frames from the MediaPlayer.
     */
    fun attach(sourceSurfaceTexture: SurfaceTexture)

    /** Called every frame — route the texture to the target sink */
    fun pushFrame(timestampNs: Long)

    /** Clean up GPU/surface/binder resources */
    fun detach()
}

// ── In-App Preview Injector ───────────────────────────────────────────────────

/**
 * Routes frames to a [Surface] owned by the app's own UI (e.g. a
 * TextureView or SurfaceView in the Compose preview widget).
 *
 * No special permissions needed.
 */
class InAppPreviewInjector(
    private val targetSurface: Surface
) : CameraInjector {

    private val TAG = "InAppPreviewInjector"

    override val requiresRoot     = false
    override val requiresLSPosed  = false
    override val displayName      = "In-App Preview"

    override fun attach(sourceSurfaceTexture: SurfaceTexture) {
        Log.d(TAG, "Attached to source SurfaceTexture")
    }

    override fun pushFrame(timestampNs: Long) {
        // In a real EGL pipeline:
        //   1. eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)
        //   2. GLES20.glBindTexture(GL_TEXTURE_EXTERNAL_OES, textureId)
        //   3. sourceSurfaceTexture.updateTexImage()
        //   4. Draw a full-screen quad to the targetSurface via EGL
        //   5. eglSwapBuffers(eglDisplay, eglSurface)
        Log.v(TAG, "pushFrame t=$timestampNs")
    }

    override fun detach() {
        Log.d(TAG, "Detached")
    }
}

// ── Camera2 Compat Injector (system-signed / root) ────────────────────────────

/**
 * Attempts to open a Camera2 virtual device via the HAL virtual camera provider
 * (available in AOSP from Android 14+ with the right system permissions, or
 * on rooted devices via Magisk/KernelSU).
 *
 * If the platform does not support it, [attach] logs a warning and no-ops.
 *
 * Full HAL implementation reference:
 *   https://source.android.com/docs/core/camera/virtualcamera
 */
class Camera2CompatInjector(private val context: Context) : CameraInjector {

    private val TAG = "Camera2CompatInjector"

    override val requiresRoot     = true
    override val requiresLSPosed  = false
    override val displayName      = "Camera2 HAL Stub"

    private var handlerThread: HandlerThread? = null
    private var handler: Handler? = null
    private var imageReader: ImageReader? = null
    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null

    override fun attach(sourceSurfaceTexture: SurfaceTexture) {
        handlerThread = HandlerThread("Camera2Injector").also { it.start() }
        handler = Handler(handlerThread!!.looper)

        val cameraManager = context.getSystemService(CameraManager::class.java)
        val targetCameraId = findFrontCamera(cameraManager) ?: return

        imageReader = ImageReader.newInstance(1280, 720, android.graphics.PixelFormat.RGBA_8888, 2)

        try {
            // On a stock device without system signature, this throws SecurityException.
            // On a rooted device with appropriate permissions it may succeed.
            @Suppress("MissingPermission")
            cameraManager.openCamera(targetCameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    cameraDevice = camera
                    startCaptureSession(camera, sourceSurfaceTexture)
                }
                override fun onDisconnected(camera: CameraDevice) { camera.close() }
                override fun onError(camera: CameraDevice, error: Int) {
                    Log.e(TAG, "Camera open error: $error")
                    camera.close()
                }
            }, handler)
        } catch (e: SecurityException) {
            Log.e(TAG, "CAMERA permission or system privilege required", e)
        } catch (e: Exception) {
            Log.e(TAG, "Camera2 attach failed", e)
        }
    }

    private fun startCaptureSession(camera: CameraDevice, srcTexture: SurfaceTexture) {
        val outputSurface = imageReader?.surface ?: return
        val previewSurface = Surface(srcTexture)

        @Suppress("DEPRECATION")
        camera.createCaptureSession(
            listOf(outputSurface, previewSurface),
            object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(session: CameraCaptureSession) {
                    captureSession = session
                    val request = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                        addTarget(previewSurface)
                    }.build()
                    session.setRepeatingRequest(request, null, handler)
                    Log.i(TAG, "Camera2 capture session active")
                }
                override fun onConfigureFailed(session: CameraCaptureSession) {
                    Log.e(TAG, "Session configure failed")
                }
            },
            handler
        )
    }

    private fun findFrontCamera(manager: CameraManager): String? {
        return manager.cameraIdList.firstOrNull { id ->
            manager.getCameraCharacteristics(id)
                .get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
        }
    }

    override fun pushFrame(timestampNs: Long) {
        // Frame routing happens inside the repeating capture request
    }

    override fun detach() {
        captureSession?.close()
        cameraDevice?.close()
        imageReader?.close()
        handlerThread?.quitSafely()
        Log.d(TAG, "Detached")
    }
}

// ── Xposed Hook Injector (LSPosed) ────────────────────────────────────────────

/**
 * Skeleton for an LSPosed Xposed module that hooks Camera / Camera2 in
 * the target app's process.
 *
 * To activate:
 *   1. Add `assets/xposed_init` → `com.vcamdroid.camera.XposedInitHook`
 *   2. Declare `<meta-data android:name="xposedmodule" android:value="true"/>` in the manifest.
 *   3. Enable this module in the LSPosed Manager for the target app.
 *
 * The hook below targets `android.hardware.Camera.open()` for legacy apps
 * and `android.hardware.camera2.CameraManager.openCamera()` for Camera2 apps.
 *
 * NOTE: This class must NOT import `de.robv.android.xposed.*` at the top level
 * because it will crash on non-Xposed devices. Use reflection or a separate
 * module APK that depends on the XposedBridge API.
 */
class XposedInjector : CameraInjector {

    override val requiresRoot     = true
    override val requiresLSPosed  = true
    override val displayName      = "Xposed / LSPosed Hook"

    override fun attach(sourceSurfaceTexture: SurfaceTexture) {
        // Hook registration happens at class-load time in XposedInitHook, not here.
        // This attach() call signals the IPC mechanism (e.g. a shared MemoryFile or
        // a ContentProvider) to start exposing frames to the hooked process.
        Log.i("XposedInjector", "Signalling Xposed hook to start consuming frames")
    }

    override fun pushFrame(timestampNs: Long) {
        // Write the latest frame to the shared buffer so the hooked app reads it
    }

    override fun detach() {
        Log.i("XposedInjector", "Signalling Xposed hook to stop")
    }
}

// ── XposedInitHook ────────────────────────────────────────────────────────────
// Kept in a separate source file in a real module to avoid class-not-found errors
// on devices without Xposed. Shown here for reference only.

/*
class XposedInitHook : IXposedHookLoadPackage {
    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        // Hook Camera2 openCamera
        XposedHelpers.findAndHookMethod(
            "android.hardware.camera2.CameraManager",
            lpparam.classLoader,
            "openCamera",
            String::class.java,
            CameraDevice.StateCallback::class.java,
            Handler::class.java,
            object : XC_MethodHook() {
                override fun beforeHookedMethod(param: MethodHookParam) {
                    // Redirect to virtual camera feed
                    param.result = null // intercept
                }
            }
        )
    }
}
*/
